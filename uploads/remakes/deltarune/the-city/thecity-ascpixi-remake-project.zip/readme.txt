hi! thank you for downloading my remake!
in order to launch this project, you'll need:

these plugins:
	- Xfer Serum (paid)
	- OTT (free) - https://xferrecords.com/freeware
	- NES VST (free) - https://www.mattmontag.com/projects-page/nintendo-vst
	- Plogue sforzando (free) - https://www.plogue.com/products/sforzando.html

in case of missing soundfonts, you should be able to find them here: https://musical-artifacts.com/

thanks! <3
- ascpixi
